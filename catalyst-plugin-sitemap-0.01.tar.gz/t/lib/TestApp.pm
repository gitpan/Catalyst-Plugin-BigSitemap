package TestApp;

use strict;
use warnings;

use Catalyst qw/ BigSitemap /;

__PACKAGE__->setup;

1;
